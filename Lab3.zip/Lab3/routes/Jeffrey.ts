﻿import assert = require('assert');

export function Test1() {
    assert.ok(true, "This shouldn't fail");
}

export function Test2() {
    assert.ok(1 === 1, "This shouldn't fail");
    assert.ok(false, "This should fail");
}

/*
 * GET users listing.
 */
import express = require('express');
const router = express.Router();

router.get('/', (req: express.Request, res: express.Response) => {
    var message = "Jeffrey is my older brother, but because of his Autism, he is mentally still a non-verbal 3-year-old.";
    res.render("Jeffrey", { key: message});
});

export default router;