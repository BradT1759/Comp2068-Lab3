﻿import assert = require('assert');

export function Test1() {
    assert.ok(true, "This shouldn't fail");
}

export function Test2() {
    assert.ok(1 === 1, "This shouldn't fail");
    assert.ok(false, "This should fail");
}
/*
 * GET users listing.
 */
import express = require('express');
const router = express.Router();

router.get('/', (req: express.Request, res: express.Response) => {
    var message = "My Mom currently works from home for Indigenous Services Canada.";
    res.render("Mom", { key: message });
});

export default router;