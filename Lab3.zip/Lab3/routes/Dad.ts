﻿import assert = require('assert');

export function Test1() {
    assert.ok(true, "This shouldn't fail");
}

export function Test2() {
    assert.ok(1 === 1, "This shouldn't fail");
    assert.ok(false, "This should fail");
}

/*
 * GET users listing.
 */
import express = require('express');
const router = express.Router();

router.get('/', (req: express.Request, res: express.Response) => {
    var message = "My dad, Brain Tobin, works with technology and is a big fan of Star Trek. He even made his own fan film when he was in college!";
    res.render("Dad", { key: message });
});

export default router;