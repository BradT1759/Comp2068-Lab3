"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var assert = require("assert");
function Test1() {
    assert.ok(true, "This shouldn't fail");
}
exports.Test1 = Test1;
function Test2() {
    assert.ok(1 === 1, "This shouldn't fail");
    assert.ok(false, "This should fail");
}
exports.Test2 = Test2;
/*
 * GET users listing.
 */
var express = require("express");
var router = express.Router();
router.get('/', function (req, res) {
    var message = "My dad, Brain Tobin, works with technology and is a big fan of Star Trek. He even made his own fan film when he was in college!";
    res.render("Dad", { key: message });
});
exports.default = router;
//# sourceMappingURL=Dad.js.map